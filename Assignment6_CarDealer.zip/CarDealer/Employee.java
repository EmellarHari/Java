package CarDealer;

public class Employee {
	private int employeeNumber;
	private String employeeName;
	
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	public void processCustomerRequest(Customer C1,Vehicle V1) {
		
		if(C1.isBlnLoanRequirement()) {
			double loanAmount=V1.getVehiclePrice() - C1.getCustomer_budget();
			this.processLoan(C1,loanAmount);
			processTransaction(C1,V1);
		}else {
			
			processTransaction(C1,V1);
		}
	} 
	
	public void processLoan(Customer C1, double loanAmout) {
		System.out.println("Loan request is registered");
	}
	private void processTransaction(Customer C1, Vehicle V1) {
		System.out.println(C1.getCustomer_Name()+" bought the vehicle " + V1.getVehicleModel() + " will be delivered in 15 days ");
		System.out.println("Thanks for your interest on our product");		
	}
}
