package CarDealer;

public class Customer {
	private long customer_aadhar_no;
	private String customer_Name;
	private String customer_Address;
	private long customer_Phone;
	private double customer_budget;
	private boolean blnLoanRequirement;
	
	
	public long getCustomer_aadhar_no() {
		return customer_aadhar_no;
	}
	public void setCustomer_aadhar_no(long customer_aadhar_no) {
		this.customer_aadhar_no = customer_aadhar_no;
	}
	
	public String getCustomer_Name() {
		return customer_Name;
	}
	public void setCustomer_Name(String customer_Name) {
		this.customer_Name = customer_Name;
	}
	public String getCustomer_Address() {
		return customer_Address;
	}
	public void setCustomer_Address(String customer_Address) {
		this.customer_Address = customer_Address;
	}
	public long getCustomer_Phone() {
		return customer_Phone;
	}
	public void setCustomer_Phone(long customer_Phone) {
		this.customer_Phone = customer_Phone;
	}
	public double getCustomer_budget() {
		return customer_budget;
	}
	public void setCustomer_budget(double customer_budget) {
		this.customer_budget = customer_budget;
	}
	public boolean isBlnLoanRequirement() {
		return blnLoanRequirement;
	}
	public void setBlnLoanRequirement(boolean blnLoanRequirement) {
		this.blnLoanRequirement = blnLoanRequirement;
	}
	
	public void purchaseVehicle(Employee E1, Vehicle V1) {
		E1.processCustomerRequest(this,V1);
	}		
}
