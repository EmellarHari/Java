package CarDealer;
import java.util.Scanner;

public class Dealer {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		Employee E1=new Employee();
		System.out.println("Enter the Employee Number");
		E1.setEmployeeNumber(scan.nextInt());
		System.out.println("Enter the Employee Name:");
		E1.setEmployeeName(scan.next());
		
		Vehicle V1=new Vehicle();
		System.out.println("Enter the Vehicle Name:");
		V1.setVehicleName(scan.next());
		
		System.out.println("Enter the Vehicle Make:");
		V1.setVehicleMake(scan.next());
		
		System.out.println("Enter the Vehicle Model:");
		V1.setVehicleModel(scan.next());
		
		System.out.println("Enter the Vehicle Price:");
		V1.setVehiclePrice(scan.nextDouble());
		
		Customer C1=new Customer();
				
		System.out.println("Enter the Customer Aadhar Number:");
		C1.setCustomer_aadhar_no(scan.nextLong());
		
		System.out.println("Enter the Customer Name:");
		C1.setCustomer_Name(scan.next());
		
		System.out.println("Enter the Customer Address:");
		C1.setCustomer_Address(scan.next());
		
		System.out.println("Enter the Customer Phone:");
		C1.setCustomer_Phone(scan.nextLong());
		
		System.out.println("Enter the Customer Budget:");
		C1.setCustomer_budget(scan.nextDouble());
		
		System.out.println("Are you going for Loan:");
		C1.setBlnLoanRequirement(scan.hasNext());
	
		C1.purchaseVehicle(E1,V1);
		scan.close();
	}

}
