package ATM;

public class CBI  extends CardDetails{
	private int intCA=3;
	
	@Override
	void ServiceCharge(){
		System.out.println("Service Charge is " + intCA + "%");
	}
}
