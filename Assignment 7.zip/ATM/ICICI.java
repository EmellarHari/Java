package ATM;

public class ICICI extends CardDetails{
	private int intCA=2;
	@Override
	void ServiceCharge(){
		System.out.println("Service Charge is " + intCA + "%");
	}
}
