package ATM;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.lang.NullPointerException;

public class atmSimulation {
	public static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args){
		System.out.println("Welcome");
		System.out.println("*******");
		int intC=1;
		int intSC=0;
		int intP=0;
		
		while(intC==1){		
			BufferedReader br=null;
			FileReader fr=null;
			try{
			CardDetails cd= new CardDetails();
			System.out.println("Enter the Card Number:");
			cd.setCardNumber(sc.nextInt());	
							
			
			fr=new FileReader("C:\\Users\\rhari9\\Desktop\\Learning\\Java\\atmCardDetails.csv");
			br=new BufferedReader(fr);
			String sFileText=br.readLine();
			while(sFileText!=null){
				sFileText=br.readLine();
				//System.out.println(sFileText);
				if (sFileText==null) {
					System.out.println("I am coming out here");
					break;
				}
				
				String[] data=sFileText.split(",",7);
				//System.out.println("Card Number in File is:"+ data[0]);
				//System.out.println(cd.getCardNumber());
				cd.setName(data[1]);
				cd.setPhone_No(data[2]);
				cd.setBank(data[3]);
				cd.setTranDate(data[4]);
				cd.setTranType(data[5].charAt(0));
				cd.setBalance(Double.parseDouble(data[6]));
	
				/*System.out.println(cd.getName());
				System.out.println(cd.getPhone_No());
				System.out.println(cd.getBank());
				System.out.println(cd.getTranDate());
				System.out.println(cd.getTranType());
				System.out.println(cd.getBalance());
				System.out.println(Integer.parseInt(data[0])==cd.getCardNumber());*/
				
				
				if (Integer.parseInt(data[0])==cd.getCardNumber()){
					intP=1;
					System.out.println("Good Day Mr." + data[1]);
					System.out.println("Please choose the option you want to proceed");
					System.out.println("1.Balance Enquiry");
					System.out.println("2.Cash WithDraw");
					System.out.println("3.Exit");
					int intUC=sc.nextInt();
					if(intUC==1){ //Balance Enquiry
						System.out.println("As of now your account balance is "+ data[6]);
						break;
					}
					else if(intUC==2){ //With Drawl
						System.out.println("Enter how much amount do you want to With Draw:");
						if(data[3].equals("ICICI")){
							ICICI obj=new ICICI();
							obj.ServiceCharge();
							obj=null;
						}else if(data[3].equals("CBI")){
							CBI obj=new CBI();
							obj.ServiceCharge();
							obj=null;
						}else if(data[3].equals("IOB")){
							IOB obj=new IOB();
							obj.ServiceCharge();
							obj=null;
						}
						
						double cashDeposit=sc.nextDouble();
						if(cd.getBalance()<cashDeposit){
							System.out.println("You do not have sufficient balance in your account number "+ cd.getCardNumber());
							System.out.println("Sorry for the disappointment");
						}else if(cashDeposit<cd.getBalance()){
							System.out.println("Wait. The Transaction is in Progress....");
							System.out.println("Please get the amount from Cash box before it takes inside");
							System.out.println("Thank You Welcome Again.");
						}
						break;
					}
					else if(intUC==3){
						System.out.println("Have a nice day.  Bye Bye");
						System.exit(0);
						break;
					}
				}
				//sFileText=br.readLine();
				if (sFileText==null) break;
				}
				if(intP==0){
					System.out.println("Invalid Card Number");
				}					
				System.out.println("Do you want to Continue(1/0):");
				intC=sc.nextInt();
		}catch(FileNotFoundException ex){
			ex.printStackTrace();
		}catch(NullPointerException ex){
			ex.printStackTrace();
		//}catch(InputMismatchException ex){
			//throw ex;
			
		}catch(Exception ex){
			ex.printStackTrace();
		}		
	}
		System.out.println("Thank you.  Visit Again.");
	}
}
