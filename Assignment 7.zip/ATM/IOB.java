package ATM;

public class IOB extends CardDetails{
	private int intCA=4;
	@Override
	void ServiceCharge(){
		System.out.println("Service Charge is " + intCA + "%");
	}
}
