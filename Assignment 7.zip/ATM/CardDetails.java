package ATM;

public class CardDetails {
	private int CardNumber;
	private String Name;
	private String Phone_No;
	private String Bank;
	private String TranDate;
	private char TranType;
	private double Balance;
	public int getCardNumber() {
		return CardNumber;
	}
	public void setCardNumber(int cardNumber) {
		CardNumber = cardNumber;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPhone_No() {
		return Phone_No;
	}
	public void setPhone_No(String phone_No) {
		Phone_No = phone_No;
	}
	public String getBank() {
		return Bank;
	}
	public void setBank(String bank) {
		Bank = bank;
	}
	public String getTranDate() {
		return TranDate;
	}
	public void setTranDate(String tranDate) {
		TranDate = tranDate;
	}
	public char getTranType() {
		return TranType;
	}
	public void setTranType(char tranType) {
		TranType = tranType;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	void ServiceCharge(){
		
	}
	
	
}
